import javax.swing.*;
import javax.swing.plaf.basic.BasicInternalFrameUI;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class SanPhamForm extends JInternalFrame {

    public SanPhamForm() {
        initComponents();
        this.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 0, 0, 0));
        BasicInternalFrameUI ui = (BasicInternalFrameUI) this.getUI();
        ui.setNorthPane(null);
        fillTable();
        disableRightClick();
    }

    private void disableRightClick() {
        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if (SwingUtilities.isRightMouseButton(e)) {
                    e.consume();  // Đánh dấu sự kiện đã được xử lý, ngăn chặn hiển thị menu chuột phải
                }
            }
        });
    }

    private void fillTable() {
        // Các thiết lập cho việc điền dữ liệu vào bảng
        // ...
    }

    private void initComponents() {
        // Khởi tạo các thành phần của JInternalFrame
        // ...
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame();
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            JDesktopPane desktopPane = new JDesktopPane();
            SanPhamForm internalFrame = new SanPhamForm();
            internalFrame.setSize(300, 200);
            internalFrame.setVisible(true);

            desktopPane.add(internalFrame);
            frame.add(desktopPane);

            frame.setSize(800, 600);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class RightClickExample extends JFrame {

    public RightClickExample() {
        setTitle("Right Click Example");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();

        // Sử dụng MouseAdapter để bắt sự kiện chuột
        panel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // Kiểm tra xem có phải là click chuột phải không (button 3 là chuột phải)
                if (e.getButton() == MouseEvent.BUTTON3) {
                    System.out.println("Đã click chuột phải một lần tại: " + e.getPoint());
                }
            }
        });

        add(panel);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        new RightClickExample();
    }
}

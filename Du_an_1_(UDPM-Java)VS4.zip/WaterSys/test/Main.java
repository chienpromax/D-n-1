import com.toedter.calendar.JDateChooser;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Main {
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            JFrame frame = new JFrame("Set Current Date Example");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(300, 200);
            frame.setLayout(new BorderLayout());

            JDateChooser dateChooser = new JDateChooser();
            JButton setDateButton = new JButton("Set Current Date");
            setDateButton.addActionListener(e -> setCurrentDate(dateChooser));

            JPanel panel = new JPanel();
            panel.add(dateChooser);
            panel.add(setDateButton);

            frame.add(panel, BorderLayout.CENTER);
            frame.setVisible(true);
        });
    }

    private static void setCurrentDate(JDateChooser dateChooser) {
        // Lấy ngày hiện tại
        Calendar calendar = Calendar.getInstance();
        Date currentDate = calendar.getTime();

        // Đặt ngày hiện tại cho JDateChooser
        dateChooser.setDate(currentDate);
    }
}

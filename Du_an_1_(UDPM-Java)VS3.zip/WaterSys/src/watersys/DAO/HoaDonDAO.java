/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package watersys.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import watersys.Entity.KhachHang;
import watersys.Entity.HoaDon;
import watersys.Utilities.XJdbc;

/**
 *
 * @author xuanc
 */
public class HoaDonDAO extends waterSysDAO<HoaDon, String>{

    String INSERT_SQL = "INSERT INTO HoaDon(MaHD, HoTenKH, NgayTao, tenSP, TongTien, MaNV, MaKH, MaBan) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
    String DELETE_SQL = "DELETE FROM HoaDon WHERE MaHD=?";
    String SELECT_ALL_SQL = "SELECT * FROM HoaDon";
    String SELECT_BY_ID_SQL = "SELECT * FROM HoaDon WHERE MaHD=?";

    
    @Override
    public void insert(HoaDon entity) {
         XJdbc.executeUpdate(INSERT_SQL,
                entity.getMaHD(),
                entity.getHoTenKH(),
                entity.getNgayTao(),
                entity.getTenpSP(),
                entity.getTongTien(),
                entity.getMaNV(),
                entity.getMaKH(),
                entity.getMaBan());
    }

    @Override
    public void update(HoaDon entity) {
    }

    @Override
    public void delete(String id) {
        XJdbc.executeUpdate(DELETE_SQL, id);
    }

    @Override
    public HoaDon selectById(String id) {
        List<HoaDon> list = this.selectBySQL(SELECT_BY_ID_SQL, id);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    public List<HoaDon> selectAll() {
        return this.selectBySQL(SELECT_ALL_SQL);
    }

    @Override
    protected List<HoaDon> selectBySQL(String sql, Object... args) {
        List<HoaDon> list = new ArrayList<>();
        try {
            ResultSet rs = XJdbc.executeQuery(sql, args);
            while (rs.next()) {
                HoaDon entity = new HoaDon();
                entity.setMaHD(rs.getString("MaHD"));
                entity.setHoTenKH(rs.getString("HoTenKH"));
                entity.setNgayTao(rs.getDate("NgayTao"));
                entity.setTenpSP(rs.getString("TenSP"));
                entity.setTongTien(rs.getFloat("TongTien"));
//                entity.setID(rs.getInt("ID"));
                entity.setMaNV(rs.getString("MaNV"));
                entity.setMaKH(rs.getString("MaKH"));
                entity.setMaBan(rs.getString("MaBan"));
                list.add(entity);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BanHangDAO;

import watersys.DAO.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import watersys.Entity.ChiTietSP;
import watersys.Entity.NhanVien;
import watersys.Entity.ChiTietSP;
import watersys.Utilities.XJdbc;

/**
 *
 * @author xuanc
 */
public class ChiTietSPDAO7 extends waterSysDAO<ChiTietSP, Integer> {

    String INSERT_SQL = "INSERT INTO ChiTietHD7(TenNuoc, Loai, SoLuong, DonGia, MaSP ) VALUES(?,?,?,?,?)";
    String UPDATE_SQL = "UPDATE ChiTietHD7 SET TenNuoc=?, Loai=?, SoLuong=?, DonGia=? MaSP=? WHERE ID=?";
    String DELETE_SQL = "DELETE FROM ChiTietHD7 WHERE ID=?";
    String SELECT_ALL_SQL = "SELECT * FROM ChiTietHD7";
    String SELECT_BY_ID_SQL = "SELECT * FROM ChiTietHD7 WHERE id=?";
    String DELETE_SQL_ALL = "DELETE FROM ChiTietHD7";


    @Override
    public void insert(ChiTietSP entity) {
        XJdbc.executeUpdate(INSERT_SQL,
                entity.getTenMuoc(),
                entity.getLoai(),
                entity.getSoLuong(),
                entity.getDonGia(),
                entity.getMaSP());
    }

    @Override
    public void update(ChiTietSP entity) {
        XJdbc.executeUpdate(INSERT_SQL,
                entity.getTenMuoc(),
                entity.getLoai(),
                entity.getSoLuong(),
                entity.getDonGia(),
                entity.getMaSP());
    }

    @Override
    public void delete(Integer id) {
        XJdbc.executeUpdate(DELETE_SQL, id);
    }
    
    public void deleteAll() {
        XJdbc.executeUpdate(DELETE_SQL_ALL);
    }
    

    @Override
    public ChiTietSP selectById(Integer id) {
        List<ChiTietSP> list = this.selectBySQL(SELECT_BY_ID_SQL, id);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    public List<ChiTietSP> selectAll() {
        return this.selectBySQL(SELECT_ALL_SQL);
    }

    @Override
    protected List<ChiTietSP> selectBySQL(String sql, Object... args) {
        List<ChiTietSP> list = new ArrayList<>();
        try {
            ResultSet rs = XJdbc.executeQuery(sql, args);
            while (rs.next()) {
                ChiTietSP entity = new ChiTietSP();

                entity.setID(rs.getInt("ID"));
                entity.setTenMuoc(rs.getString("TenNuoc"));
                entity.setLoai(rs.getString("Loai"));
                entity.setSoLuong(rs.getInt("SoLuong"));
                entity.setDonGia(rs.getFloat("DonGia"));
                entity.setMaSP(rs.getString("MaSP"));
                list.add(entity);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}

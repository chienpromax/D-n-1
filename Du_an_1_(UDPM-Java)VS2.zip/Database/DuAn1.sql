﻿create database DuAn1_VS1

create table NhanVien(
	MaNV nvarchar (20) primary key NOT NULL,
	MatKhau nvarchar (50) not null,
	VaiTro bit default 0,
	HoTen nvarchar(50) not null,
	SDT nvarchar(24) not null,
	GioiTinh bit default 0,
	NgaySinh date not null,
	Luong float not null,
	Hinh nvarchar(20) not null,
	Email nvarchar(50) not null,
)
create table SanPham(
	MaSP nvarchar(20) primary key NOT NULL,
	Loai nvarchar(50) not null,
	TenNuoc nvarchar(50) not null,
	Anh nvarchar(50) not null,
	DonGia float not null,
	NgayThem date not null,
	MoTa nvarchar(250),
	MaNV nvarchar(20) not null,
	SoLuong int not null
	foreign key(MaNV) references NhanVien(MaNV) on update cascade
)

create table KhachHang(
	MaKH nvarchar(20) primary key NOT NULL,
	HoTenKH nvarchar(50) not null,
	GioiTinh bit default 1,
	SDT nvarchar(20) not null,
	NgayMua date not null,
	DanhGia nvarchar(50),
)
create table Ban(
	MaBan nvarchar(20) primary key,
	HoTenKH nvarchar(50) ,
	TrangThai nvarchar(50)
)
create table ChiTietHD(
	ID INT identity(1,1) primary key NOT NULL,
	TenNuoc nvarchar(50) not null,
	Loai nvarchar(50) not null,
	SoLuong int not null,
	DonGia float not null,
	MaSP nvarchar(20),
	foreign key(MaSP) references SanPham(MaSP)
)

delete from KhachHang where MaKH = 'kh01'
create table HoaDon(
	MaHD nvarchar(20) primary key NOT NULL,
	HoTenKH nvarchar(50) not null,
	NgayTao date not null,
	TenSP nvarchar(100) not null,
	TongTien float not null,
	ID INT,
	MaNV nvarchar(20) not null,
	MaKH nvarchar(20) not null,
	MaBan nvarchar(20),
	foreign key(MaNV) references NhanVien(MaNV),
	foreign key(MaKH) references KhachHang(MaKH),
	foreign key(ID) references ChiTietHD(ID),
	foreign key(MaBan) references Ban(MaBan)
)

GO
INSERT NhanVien ([MaNV], MatKhau, VaiTro, [HoTen], SDT, [NgaySinh], [GioiTinh], Luong, [Hinh], Email) VALUES ('NV01', '12345', 0, N'Trần xuân chiến', '0359690062', '07-11-2023', 1, 9000000, N'yea.jpg',N'xuanchient033@gmail.com')
INSERT NhanVien ([MaNV], MatKhau, VaiTro, [HoTen], SDT, [NgaySinh], [GioiTinh], Luong, [Hinh], Email) VALUES ('NV02', '12345', 1, N'LỮ HUY CƯỜNG','0359690062', '07-11-2023', 0, 9000000, N'Image.jpg',N'chientxpd08548@fpt.edu.vn')
INSERT NhanVien ([MaNV], MatKhau, VaiTro, [HoTen], SDT, [NgaySinh], [GioiTinh], Luong, [Hinh], Email) VALUES ('NV03', '12345', 1, N'ĐỖ VĂN MINH','0359690062', '07-11-2023', 0, 9000000, N'GAME.png',N'xuanchient033@gmail.com')
INSERT NhanVien ([MaNV], MatKhau, VaiTro, [HoTen], SDT, [NgaySinh], [GioiTinh], Luong, [Hinh], Email) VALUES ('NV04', '12345', 1, N'NGUYỄN TẤN HIẾU','0359690062', '07-11-2023', 1, 9000000, N'GAME.png',N'xuanchient033@gmail.com')
INSERT NhanVien ([MaNV], MatKhau, VaiTro, [HoTen], SDT, [NgaySinh], [GioiTinh], Luong, [Hinh], Email) VALUES ('NV05', '12345', 0, N'TRẦN VĂN NAM','0359690062', '07-11-2023', 1, 9000000, N'GAME.png',N'xuanchient033@gmail.com')


INSERT SanPham ([MaSP], Loai, [TenNuoc], Anh, DonGia, [NgayThem], MoTa, MaNV) VALUES ('SP01', N'Nước ngọt', N'Pesi', N'GAME.png', 10000, '07-11-2023', N'nước uống ngon tuyệt vời', N'NV01')
INSERT SanPham ([MaSP], Loai, [TenNuoc], Anh, DonGia, [NgayThem], MoTa, MaNV) VALUES ('SP02', N'Nước ngọt', N'coca cola', N'GAME.png', 11000, '07-11-2023', N'nước uống ngon tuyệt vời', N'NV01')
INSERT SanPham ([MaSP], Loai, [TenNuoc], Anh, DonGia, [NgayThem], MoTa, MaNV) VALUES ('SP03', N'Nước khoáng', N'aqua vina', N'GAME.png', 12000, '07-11-2023', N'nước uống ngon tuyệt vời', N'NV01')
INSERT SanPham ([MaSP], Loai, [TenNuoc], Anh, DonGia, [NgayThem], MoTa, MaNV) VALUES ('SP04', N'Nước ép', N'nước cam', N'GAME.png', 13000, '07-11-2023', N'nước uống ngon tuyệt vời', N'NV01')
INSERT SanPham ([MaSP], Loai, [TenNuoc], Anh, DonGia, [NgayThem], MoTa, MaNV) VALUES ('SP05', N'Nước ngọt', N'7 up', N'GAME.png', 14000, '07-11-2023', N'nước uống ngon tuyệt vời', N'NV01')


INSERT KhachHang ([MaKH], HoTenKH, GioiTinh, SDT, NgayMua, DanhGia) VALUES (N'Mang Về', N'Trần xuân chiến', 1, '0359698875', '07-11-2023', N'tuyệt vời')
INSERT KhachHang ([MaKH], HoTenKH, GioiTinh, SDT, NgayMua, DanhGia) VALUES (N'KH01', N'Trần xuân chiến', 1, '0359698875', '07-11-2023', N'tuyệt vời')
INSERT KhachHang ([MaKH], HoTenKH, GioiTinh, SDT, NgayMua, DanhGia) VALUES (N'KH02', N'Trần xuân chiến1', 0, '0359698875', '07-11-2023', N'tuyệt vời')
INSERT KhachHang ([MaKH], HoTenKH, GioiTinh, SDT, NgayMua, DanhGia) VALUES (N'KH03', N'Trần xuân chiến2', 1, '0359698875', '07-11-2023', N'tuyệt vời')
INSERT KhachHang ([MaKH], HoTenKH, GioiTinh, SDT, NgayMua, DanhGia) VALUES (N'KH04', N'Trần xuân chiến3', 1, '0359698875', '07-11-2023', N'tuyệt vời')


INSERT Ban ([MaBan], [HoTenKH], [TrangThai]) VALUES (N'Ban1', N'Trần xuân chiến', N'Đặt bàn')
INSERT Ban ([MaBan], [HoTenKH], [TrangThai]) VALUES (N'Ban2', N'Trần xuân chiến1', N'Đang dùng')
INSERT Ban ([MaBan], [HoTenKH], [TrangThai]) VALUES (N'Ban3', N'', N'Trống')
INSERT Ban ([MaBan], [HoTenKH], [TrangThai]) VALUES (N'Ban4', N'', N'Trống')
INSERT Ban ([MaBan], [HoTenKH], [TrangThai]) VALUES (N'Ban5', N'', N'Trống')
INSERT Ban ([MaBan], [HoTenKH], [TrangThai]) VALUES (N'Ban6', N'', N'Trống')
INSERT Ban ([MaBan], [HoTenKH], [TrangThai]) VALUES (N'Ban7', N'', N'Trống')
INSERT Ban ([MaBan], [HoTenKH], [TrangThai]) VALUES (N'Ban8', N'', N'Trống')
INSERT Ban ([MaBan], [HoTenKH], [TrangThai]) VALUES (N'Ban9', N'', N'Trống')
INSERT Ban ([MaBan], [HoTenKH], [TrangThai]) VALUES (N'Ban10', N'', N'Trống')
INSERT Ban ([MaBan], [HoTenKH], [TrangThai]) VALUES (N'Ban11', N'', N'Trống')
INSERT Ban ([MaBan], [HoTenKH], [TrangThai]) VALUES (N'Ban12', N'', N'Trống')
INSERT Ban ([MaBan], [HoTenKH], [TrangThai]) VALUES (N'Mang vỀ', N'', N'Trống')


INSERT ChiTietHD ( [TenNuoc], Loai, [SoLuong], [DonGia], MaSP) VALUES ( N'pesi', N'Nước ngọt', 5, 10000, 'SP01')
INSERT ChiTietHD ( [TenNuoc], Loai, [SoLuong], [DonGia], MaSP) VALUES ( N'cosi', N'Nước ngọt', 5, 10000, 'SP02')
INSERT ChiTietHD ( [TenNuoc], Loai, [SoLuong], [DonGia], MaSP) VALUES ( N'peco', N'Nước ngọt', 5, 10000, 'SP03')


INSERT HoaDon ([MaHD], [HoTenKH], [NgayTao], TenSP, TongTien, [MaNV], MaKH, MaBan) VALUES (N'HD001', N'Trần xuân chiến', '07-11-2023', N'pesi, coca', 50000, 'NV01', 'KH01', 'Ban1')
INSERT HoaDon ([MaHD], [HoTenKH], [NgayTao], TenSP, TongTien, [MaNV], MaKH, MaBan) VALUES (N'HD002', N'Trần xuân chiến1', '07-11-2023', N'pesi, coca', 50000, 'NV02', 'KH02', 'Ban2')
INSERT HoaDon ([MaHD], [HoTenKH], [NgayTao], TenSP, TongTien, [MaNV], MaKH, MaBan) VALUES (N'HD003', N'Trần xuân chiến2', '07-11-2023', N'pesi, coca', 50000, 'NV01', 'KH01', N'Ban1')

DROP TABLE ban

DROP TABLE KhachHang
select * from KHachhang
select * from HoaDon


create table ChiTietHD1(
	ID INT identity(1,1) primary key NOT NULL,
	TenNuoc nvarchar(50) not null,
	Loai nvarchar(50) not null,
	SoLuong int not null,
	DonGia float not null,
	MaSP nvarchar(20),
	foreign key(MaSP) references SanPham(MaSP)
)
create table ChiTietHD2(
	ID INT identity(1,1) primary key NOT NULL,
	TenNuoc nvarchar(50) not null,
	Loai nvarchar(50) not null,
	SoLuong int not null,
	DonGia float not null,
	MaSP nvarchar(20),
	foreign key(MaSP) references SanPham(MaSP)
)
create table ChiTietHD3(
	ID INT identity(1,1) primary key NOT NULL,
	TenNuoc nvarchar(50) not null,
	Loai nvarchar(50) not null,
	SoLuong int not null,
	DonGia float not null,
	MaSP nvarchar(20),
	foreign key(MaSP) references SanPham(MaSP)
)
create table ChiTietHD4(
	ID INT identity(1,1) primary key NOT NULL,
	TenNuoc nvarchar(50) not null,
	Loai nvarchar(50) not null,
	SoLuong int not null,
	DonGia float not null,
	MaSP nvarchar(20),
	foreign key(MaSP) references SanPham(MaSP)
)
create table ChiTietHD5(
	ID INT identity(1,1) primary key NOT NULL,
	TenNuoc nvarchar(50) not null,
	Loai nvarchar(50) not null,
	SoLuong int not null,
	DonGia float not null,
	MaSP nvarchar(20),
	foreign key(MaSP) references SanPham(MaSP)
)
create table ChiTietHD6(
	ID INT identity(1,1) primary key NOT NULL,
	TenNuoc nvarchar(50) not null,
	Loai nvarchar(50) not null,
	SoLuong int not null,
	DonGia float not null,
	MaSP nvarchar(20),
	foreign key(MaSP) references SanPham(MaSP)
)
create table ChiTietHD7(
	ID INT identity(1,1) primary key NOT NULL,
	TenNuoc nvarchar(50) not null,
	Loai nvarchar(50) not null,
	SoLuong int not null,
	DonGia float not null,
	MaSP nvarchar(20),
	foreign key(MaSP) references SanPham(MaSP)
)
create table ChiTietHD8(
	ID INT identity(1,1) primary key NOT NULL,
	TenNuoc nvarchar(50) not null,
	Loai nvarchar(50) not null,
	SoLuong int not null,
	DonGia float not null,
	MaSP nvarchar(20),
	foreign key(MaSP) references SanPham(MaSP)
)
create table ChiTietHD9(
	ID INT identity(1,1) primary key NOT NULL,
	TenNuoc nvarchar(50) not null,
	Loai nvarchar(50) not null,
	SoLuong int not null,
	DonGia float not null,
	MaSP nvarchar(20),
	foreign key(MaSP) references SanPham(MaSP)
)
create table ChiTietHD10(
	ID INT identity(1,1) primary key NOT NULL,
	TenNuoc nvarchar(50) not null,
	Loai nvarchar(50) not null,
	SoLuong int not null,
	DonGia float not null,
	MaSP nvarchar(20),
	foreign key(MaSP) references SanPham(MaSP)
)